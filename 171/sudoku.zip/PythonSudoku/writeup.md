MiniProject
===========

##### James Albert 16001435
##### Max Rose 35632705

### Analysis

As tedious as it was to watch some of these combination of tokens to finish, one stood out clearly being the fastest. It was (LCV NKT NKD ACP MRV).

I judged this decision based on runtime, number of nodes created, and number of backtracks. I got this output:

```
{'ACP_DH': {'backtracks': 2622.0, 'nodes': 2824.0, 'time': 185.2909429},
 'ACP_MRV': {'backtracks': 1885.0, 'nodes': 2092.0, 'time': 139.777325}}
min time: ACP_MRV
min backtracks: ACP_MRV
min nodes: ACP_MRV
max time: ACP_DH
max backtracks: ACP_DH
max nodes: ACP_DH
```

While all parts of the assignment are complete, we only had time to measure 2 of them. Here are some charts to represent the data: (the tokens are in each chart at the bottom)

![](acp_mrv.png)

![](acp_dh.png)

I included the script I used to run and compare all possible combinations of the tokens, `runner.py`
